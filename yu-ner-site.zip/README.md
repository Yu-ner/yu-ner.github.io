# Bloodborne Devil Empress in Marvel: reader site

A static reading site for GitHub Pages. No build step, no framework, no dependencies.

## What's in the folder

```
index.html              page shell (replaces your current index.html)
styles/style.css        all styling (replaces your style.css; colours and fonts are the tokens at the top)
scripts/main.js         the reader (replaces your main.js)
scripts/markdown.js     small Markdown converter for chapter files
chapters/               one .md file per chapter, plus chapters.json (the chapter list)
chapters/about.md       the story intro shown on the home page (your original text)
tools/build-manifest.js builds chapters.json from the .md files
.github/workflows/      rebuilds chapters.json automatically when you push a chapter
images/                 yours, unchanged (seol_hwa.png and seol_hwa2.png are used on the home page)
```

## Publishing a new chapter

1. Save the chapter as `chapters/045.md` (start the name with the chapter number).
2. Put this at the top of the file:

   ```
   ---
   title: Your Chapter Title
   date: 2026-10-27
   ---
   ```

3. Commit and push (or upload the file on github.com).

The included GitHub Action rebuilds `chapters/chapters.json` for you. If you'd rather do it by hand, run `node tools/build-manifest.js` before committing.

Chapters 1 to 3 are sample text. Delete them and add your own 1 to 44 in the same way.

## Writing format

Blank line between paragraphs. `*italics*`, `**bold**`, `***both***`.
A line with `---` or `* * *` is a scene break. `> text` makes a boxed block (good for notices and signs).
`<!-- anything here -->` is a note to yourself and never shows up on the site.

## Changing the home page

- **Story intro:** edit `chapters/about.md`.
- **Images:** the `images` list in `chapters/chapters.json`. Click the picture on the home page to switch between them. Add a third image and it cycles through all of them.
- **Ko-fi link and disclaimer:** the `links` and `disclaimer` entries in the same `site` block. The build tool never overwrites that block.
- **Name greeting:** "Seol Hwa is cool, (name)" and the "Change user" button still work. They now use a small inline field instead of a pop-up, and nothing blocks the page on first visit. Names already saved in a visitor's browser carry over.

## Preview on your computer

Opening `index.html` by double-click will not work, because browsers block loading the chapter files from disk. Run this in the folder and open http://localhost:8000:

```
python -m http.server
```

## Features

- Dark, light and sepia themes, plus Auto (follows the device)
- Text size and serif or sans typeface, remembered per device
- Remembers where you stopped in each chapter, and marks finished chapters
- Chapter drawer, previous and next, and left and right arrow keys
- Every chapter has its own link, like `yu-ner.github.io/#chapter-12`
