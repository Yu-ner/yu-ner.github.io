#!/usr/bin/env node
/*
 * Builds chapters/chapters.json from the Markdown files in chapters/.
 *
 *   node tools/build-manifest.js
 *
 * Chapter number: "chapter:" in the front matter, else the digits at the start
 * of the file name (012.md, 12-the-bell.md).
 * Title: "title:" in the front matter, else the first "# Heading", else "Chapter N".
 * Date: "date:" (YYYY-MM-DD) in the front matter. If missing, the date already in
 * chapters.json is kept; for a brand new file, today's date is used.
 *
 * The "site" block of chapters.json (title, blurb, links) is never touched.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const MD = require('../scripts/markdown.js');

const dir = path.join(__dirname, '..', 'chapters');
const out = path.join(dir, 'chapters.json');

const DEFAULT_SITE = {
  title: 'Bloodborne Devil Empress in Marvel',
  author: 'Yu-ner',
  about: 'chapters/about.md',
  images: [
    { src: 'images/seol_hwa.png', alt: 'Seol Hwa looking at the viewer from a white void' },
    { src: 'images/seol_hwa2.png', alt: 'Seol Hwa, second image' }
  ],
  links: [{ label: 'Buy me a Coffee', url: 'https://ko-fi.com/yunerr21' }],
  disclaimer: 'Fan fiction. Marvel and Bloodborne belong to their respective owners.'
};

let previous = {};
try { previous = JSON.parse(fs.readFileSync(out, 'utf8')); } catch (e) { /* first run */ }
const knownDates = new Map((previous.chapters || []).map((c) => [c.n, c.date]));
const today = new Date().toISOString().slice(0, 10);

const files = fs.readdirSync(dir)
  .filter((f) => /\.md$/i.test(f) && !/^(readme|about)\.md$/i.test(f))
  .sort();

const chapters = [];
const seen = new Map();

for (const file of files) {
  const parsed = MD.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
  const lead = /^(\d+)/.exec(file);
  const n = parsed.meta.chapter ? parseInt(parsed.meta.chapter, 10) : lead ? parseInt(lead[1], 10) : NaN;

  if (!Number.isInteger(n) || n < 1) {
    console.warn(`Skipped ${file}: start the file name with the chapter number (for example 012.md).`);
    continue;
  }
  if (seen.has(n)) {
    console.error(`Chapter ${n} appears twice: ${seen.get(n)} and ${file}. Fix one of them and run again.`);
    process.exit(1);
  }
  seen.set(n, file);

  chapters.push({
    n,
    title: parsed.title || `Chapter ${n}`,
    file: `chapters/${file}`,
    date: parsed.meta.date || knownDates.get(n) || today,
    words: parsed.words
  });
}

chapters.sort((a, b) => a.n - b.n);

fs.writeFileSync(out, JSON.stringify({ site: previous.site || DEFAULT_SITE, chapters }, null, 2) + '\n');
console.log(`Wrote ${path.relative(process.cwd(), out)} with ${chapters.length} chapter${chapters.length === 1 ? '' : 's'}.`);
